package com.verizon.nationalgrid.businessservice;

import java.util.ArrayList;
import java.util.Properties;

import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.xml.VoiceElementConfig;
import com.audium.server.xml.VoiceElementConfig.AudioGroup;

import com.verizon.nationalgrid.log.APILogger;
import com.verizon.nationalgrid.ivrcommon.CallStudioUtil;

public class PP8190XferMessage implements VoiceElementInterface {

	private APILogger log;

	@Override
	public VoiceElementConfig getConfig(String name, ElementAPI data,
			VoiceElementConfig config) throws AudiumException {

		this.log = new APILogger(data, name);

		return getVoiceConfig(name, data, config);
	}

	private VoiceElementConfig getVoiceConfig(String name, ElementAPI data,
			VoiceElementConfig config) {

		try {
			CallStudioUtil callStudioUtil = CallStudioUtil.getInstance();
			// callStudioUtil.printSettingValues(name, data, config);

			String audioGroupName = "initial_audio_group";
			boolean allowBargein = false;
			int audioGroupCnt = 1;

			String xferMessage = (data.getSessionData("XferMessage")==null)?null:(String)data.getSessionData("XferMessage");
			
			if (xferMessage!=null) {
				
				log.debug(String.format("PP8190XferMessage: %s", xferMessage));
				
				AudioGroup audioGroup = config.new AudioGroup(audioGroupName,
						allowBargein, audioGroupCnt);
				
				if (xferMessage.endsWith(".wav")) {
					String xferMessageId = xferMessage.substring(0, xferMessage.indexOf("."));
					callStudioUtil.addAudiosInGroup(data, config, audioGroup,
							new String[] { xferMessageId});
				} else {
					String xferMessageId = findAudioId(xferMessage);
					
					ArrayList<String> playMonitorMsgGroup = new ArrayList<String>();
					playMonitorMsgGroup.add("pensions");
					playMonitorMsgGroup.add("voice_mail");
					playMonitorMsgGroup.add("representative");
					
					if (playMonitorMsgGroup.contains(xferMessage)) {
						callStudioUtil.addAudiosInGroup(data, config, audioGroup,
								new String[] { xferMessageId});
						callStudioUtil.addAudiosInGroup(data, config, audioGroup,
								new String[] { "729005" });
					} else {
						callStudioUtil.addAudiosInGroup(data, config, audioGroup,
								new String[] { xferMessageId});
					}
				}
				
				config.setAudioGroup(audioGroup);
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.debug("Error:(%s)", e.getMessage());
		}

		return config;
	}

	private String findAudioId(String audioName) {
		Properties nameIdMaps = new Properties();
		nameIdMaps.put("med_dent".toUpperCase(), "820001");
		nameIdMaps.put("eligibility".toUpperCase(), "820001");
		nameIdMaps.put("spend_acct".toUpperCase(), "820001");
		nameIdMaps.put("life_insurance".toUpperCase(), "820003");
		nameIdMaps.put("retiree_life_insurance".toUpperCase(), "820003");
		nameIdMaps.put("401k".toUpperCase(), "820004");
		nameIdMaps.put("pensions_nomsg".toUpperCase(), "820005");
		nameIdMaps.put("retiree_bill".toUpperCase(), "820007");
		nameIdMaps.put("representative_nomsg".toUpperCase(), "820017");
		nameIdMaps.put("home_auto".toUpperCase(), "820020");
		nameIdMaps.put("employee_stock".toUpperCase(), "820021");
		nameIdMaps.put("verify_employ".toUpperCase(), "820010");
		
		nameIdMaps.put("pensions".toUpperCase(), "820005");
		nameIdMaps.put("voice_mail".toUpperCase(), "820011");		
		nameIdMaps.put("representative".toUpperCase(), "820017");
		nameIdMaps.put("goodbye".toUpperCase(), "820019");
		
		String audioId = nameIdMaps.getProperty(audioName.toUpperCase(), "820017");
		
		return audioId;
	}
}
