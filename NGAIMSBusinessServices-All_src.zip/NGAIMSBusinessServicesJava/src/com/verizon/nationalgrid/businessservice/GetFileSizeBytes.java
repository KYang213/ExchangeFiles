package com.verizon.nationalgrid.businessservice;

import com.audium.server.AudiumException;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.xml.DecisionElementConfig;
import com.audium.server.session.DecisionElementData;
import com.verizon.nationalgrid.ivrfusion.base.DecisionElementBase;
import com.verizon.nationalgrid.log.APILogger;
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetFileSizeBytes extends DecisionElementBase implements
		ElementInterface {

	private APILogger log;
	
	enum ExitStatesEnum {
		Yes, No
	}	
	
	@Override
	public ExitState[] getExitStates() {
		ExitStatesEnum exitStates[] = ExitStatesEnum.values();
		ExitState[] es = new ExitState[exitStates.length];
		int i = 0;
		for (ExitStatesEnum oneEs : exitStates) {
			es[i] = new ExitState(oneEs.toString(), oneEs.toString(),
					oneEs.toString());
			i++;
		}
		return es;
	}		
	
	public String getElementName() {
		return "GetFileSizeBytes";
	}

	public String getDisplayFolderName() {
		return "CVP Custom Elements";
	}

	public String getDescription() {
		return "This element returns the file size in bytes\n"
				+ "into the element variable size if the file exists \n"
				+ "otherwise returns 0";
	}

	public Setting[] getSettings() throws ElementException {
		Setting[] settingArray = new Setting[4];

		settingArray[0] = new Setting("file", "filename",
				"only file name", true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.STRING);

		settingArray[1] = new Setting("size_threshold",
				"size threshold",
				"if the file size >= this value, the exit status will be Yes",
				Setting.REQUIRED, // true
				Setting.SINGLE, // true
				Setting.SUBSTITUTION_ALLOWED, // true
				new Integer(0), null);
		settingArray[1].setDefaultValue("0");		
		
		settingArray[2] = new Setting("path", 
				"file path",
				"file path", true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.STRING);		
		
		settingArray[3] = new Setting("test_file", "test filename",
				"the file name for non-prod", true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.STRING);		
		
		return settingArray;
	}

	public ElementData[] getElementData() throws ElementException {
		return null;
	}

	@Override
	public String vzDoDecision(String name, DecisionElementData data)
			throws AudiumException {
		
		ExitStatesEnum exitState = ExitStatesEnum.No;

		try {
			this.log = new APILogger(data, name);
			
			String appEnv = (String)data.getSessionData("appEnv");
			
			DecisionElementConfig config = data.getDecisionElementConfig();
			Integer sizeThreshold = Integer.parseInt(config.getSettingValue("size_threshold", data));
			Boolean useProdSetting = appEnv.equalsIgnoreCase("PROD") || appEnv.equalsIgnoreCase("UAT");
			//Boolean useProdSetting = appEnv.equalsIgnoreCase("PROD");
			String fileName = useProdSetting? config.getSettingValue("file", data): config.getSettingValue("test_file", data);		
			String fullFileName = config.getSettingValue("path", data) + fileName;
			
			Integer size = 0; // fileSize(filename);
			
			File file = new File(fullFileName);
			log.info("%s(%s) sizeThreshold:%d exists:%s isFile:%s", appEnv, fullFileName, sizeThreshold, file.exists(), file.isFile());
			
			if (file.exists() && file.isFile()) {
				size = (int) file.length();
			} else {
				log.info("can not find the file: %s", fullFileName);
			}
			
			data.setElementData("filename", fileName);
			data.setElementData("size", size.toString());
			log.info("Element Data:filename:%s size:%s", fileName, size.toString());
			
			if (size > sizeThreshold) {
				exitState = ExitStatesEnum.Yes;
			}			
			
		} catch (Exception e) {
			e.printStackTrace();
			data.setElementData("status", "failure");
		}
			
		
		return exitState.toString();
	}

}
