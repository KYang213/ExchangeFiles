package com.verizon.nationalgrid.businessservice;

import com.audium.server.AudiumException;
import com.audium.server.session.ActionElementData;
import com.audium.server.voiceElement.ActionElementBase;

import com.verizon.nationalgrid.log.APILogger;

public class LogRouteData extends ActionElementBase {

	private APILogger log;
	
	@Override
	public void doAction(String name, ActionElementData data) throws AudiumException {
		
		this.log = new APILogger(data, name);
				
		log.info("CallerInput=%s", getSessionVarValue(data, "ICMCallerInput")); 
		log.info("ExtVXML_0=%s", getSessionVarValue(data, "External_0"));
		log.info("ExtVXML_1=%s", getSessionVarValue(data, "External_1"));
		log.info("ExtVXML_2=%s", getSessionVarValue(data, "External_2"));
		log.info("ExtVXML_3=%s", getSessionVarValue(data, "External_3"));
		
		return;
	}

	private String getSessionVarValue(ActionElementData data, String varName) {
		String varValue =  (data.getSessionData(varName)==null)? "":(String)data.getSessionData(varName);
		return varValue;
	}

}