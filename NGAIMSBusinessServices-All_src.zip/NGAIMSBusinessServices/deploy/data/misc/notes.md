### 2025-12 release 
#### NGAIMSBusinessServices_v2.0.5
SIT: 10/29/25 UAT: 11/13/25 PROD: 12/04/25

- updated the TTS text for 802001


### 2024-03 release 
#### NGAIMSBusinessServices_v2.0.4
SIT: 3/6/24 UAT: 3/14/24 PROD: 3/21/24
- AIMCJ-1131: Business Service- Redesign of business services base off Tuning Recommendation
  - Removed 8080, 8012
  - Created 8025 to be an adhoc messaging during open enrollment.
  - Created 8085 to siphon off Medical/Dental/Legal callers with a yes/no question.
  - Updated 8020 logic to pass through new Open Enrollment Messaging.
  - Updated 8040 to be a yes/no prompt.
  - Updated 8050 logic for procurement to be transferred instead of going to newly removed 8080.
  - Updated 8075 for No Input/No Match to continue to transfer if there is a no match instead of going to newly removed 8080.
  - Updated 8070 EmployeeSvcs to update the verbiage and to remove Verify Employment option.
  - Updated 8090 to reorder by popularity and to remove Medical/Dental/Legal option. removed spend_acct and other_benefits options
  - Updated 8100 to update messaging and to reorder to reduce confusion. Added something else to 8100.
  - Updated 8160 verbiage from other inquiries to help me with something else.
  - Updated 8190 transfer messaging for pensions_nomsg, retiree_bill and pensions based on Bus Svc requirments.

